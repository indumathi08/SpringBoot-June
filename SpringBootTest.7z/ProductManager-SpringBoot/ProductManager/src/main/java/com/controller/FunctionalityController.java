package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Functionality;
import com.service.FunctionalityService;

@Controller
public class FunctionalityController {

	@Autowired
	private FunctionalityService service; 
	
	@RequestMapping("/viewFunctionality")
	public String viewHomePage(Model model) {
		List<Functionality> listFunctions = service.listAll();
		for(Functionality function:listFunctions){
		System.out.println("in functionalityController::::::::::::"+function.getDependentModules().size());
		}
		model.addAttribute("listFunctions", listFunctions);
		
		return "index";
	}

}
