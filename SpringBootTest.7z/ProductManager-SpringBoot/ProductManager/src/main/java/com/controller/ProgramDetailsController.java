package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dao.ProgramDetailsRepository;
import com.model.DependentModules;
import com.model.ProgramDetails;
import com.service.ProgramDetailsService;

@Controller
public class ProgramDetailsController {

	@Autowired
	private ProgramDetailsService service; 
	
	@Autowired
	private ProgramDetailsRepository repo;
	
	@RequestMapping("/viewAllProgramDetails")
	public String viewHomePage(Model model) {

		List<ProgramDetails> listPrograms = service.listAll();
		for(ProgramDetails program:listPrograms){
		System.out.println("in ProgramDetailsController::::::::::::"+program);
		}
		model.addAttribute("listPrograms", listPrograms);
		
		return "DisplayPrograms";
	}
	
		
	@RequestMapping("/viewByDepModId/{depMod_Id}")
	public String findByDependentModulesId(Model model, @PathVariable(value="depMod_Id") Long depModId) {

		List<ProgramDetails> listPrograms = service.findByDependentModulesId(depModId);
		for(ProgramDetails program:listPrograms){
		System.out.println("in ProgramDetailsController::::::::::::"+program);
		}
		model.addAttribute("listPrograms", listPrograms);
		
		return "DisplayPrograms";
	}


}
