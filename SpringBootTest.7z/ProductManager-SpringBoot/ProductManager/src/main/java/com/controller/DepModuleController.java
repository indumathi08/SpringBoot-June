package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.dao.DepModuleRepository;

import com.model.DependentModules;
import com.model.Functionality;
import com.service.DepModuleService;

@Controller
public class DepModuleController {

	@Autowired
	private DepModuleService service; 
	
	@Autowired
	private DepModuleRepository repo;
	
	@RequestMapping("/viewAllDepMod")
	public String viewHomePage(Model model) {

		List<DependentModules> listModules = service.listAll();
		for(DependentModules module:listModules){
		System.out.println("in DepModuleController::::::::::::"+module);
		}
		model.addAttribute("listModules", listModules);
		
		return "DisplayDepModules";
	}
	
		
	@RequestMapping("/viewByFuncId/{func_Id}")
	public String findByFunctionalityId(Model model, @PathVariable(value="func_Id") Long funcId) {

		List<DependentModules> listModules = service.findByFunctionalityId(funcId);
		for(DependentModules module:listModules){
		System.out.println("in DepModuleController::::::::::::"+module);
		}
		model.addAttribute("listModules", listModules);
		
		return "DisplayDepModules";
	}


}
