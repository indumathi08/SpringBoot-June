package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.FunctionalityRepository;
import com.model.Functionality;

@Service
@Transactional
public class FunctionalityService {

	@Autowired
	private FunctionalityRepository repo;
	
	public List<Functionality> listAll() {
		System.out.println("In service class" + repo);
	
		List<Functionality> listFunctions=repo.findAll();
	/*	Functionality fun=new Functionality();
		fun.setCreated_by("Indu");
		fun.setFunc_name("MDB");
		fun.setUpdated_by("Indu");
		Functionality savedFun=repo.save(fun);
		System.out.println("savedFun--" + savedFun);
		System.out.println("list size--" + listFunctions.size());*/
		for(Functionality function:listFunctions){
			System.out.println("function in service class::::::::::::"+function);
			}
		return repo.findAll();
	}
	
}
