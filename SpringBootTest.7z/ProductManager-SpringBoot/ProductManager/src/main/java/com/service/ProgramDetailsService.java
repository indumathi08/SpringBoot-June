package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.ProgramDetailsRepository;
import com.model.DependentModules;
import com.model.ProgramDetails;

@Service
@Transactional
public class ProgramDetailsService {

	@Autowired
	private ProgramDetailsRepository repo;
	
	public List<ProgramDetails> listAll() {
		System.out.println("In service class ProgramDetails" + repo);
	
		List<ProgramDetails> listPrograms=(List<ProgramDetails>) repo.findAll();
		for(ProgramDetails program:listPrograms){
			System.out.println("function in service class::::::::::::"+program);
			}
		return repo.findAll();
	}
		
	public List<ProgramDetails> findByDependentModulesId(Long modId) {
		System.out.println("In service class" + repo);
	
		List<ProgramDetails> listPrograms=repo.findByDependentModulesId(modId);
		for(ProgramDetails program:listPrograms){
			System.out.println("function in service class findByDependentModulesId::::::::::::"+program);
			}
		return listPrograms;
	}
	
}
