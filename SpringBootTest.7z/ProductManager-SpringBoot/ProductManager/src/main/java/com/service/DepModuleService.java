package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.DepModuleRepository;

import com.model.DependentModules;

@Service
@Transactional
public class DepModuleService {

	@Autowired
	private DepModuleRepository repo;
	
	public List<DependentModules> listAll() {
		System.out.println("In service class" + repo);
	
		List<DependentModules> listFunctions=(List<DependentModules>) repo.findAll();
		for(DependentModules function:listFunctions){
			System.out.println("function in service class::::::::::::"+function);
			}
		return repo.findAll();
	}
	
	/*public List<DependencyModule> listByDepModuleId(long id) {
		System.out.println("In service class" + repo);
	
		List<DependencyModule> listFunctions=repo.findByDepModuleId(id);
		for(DependencyModule function:listFunctions){
			System.out.println("function in service class::::::::::::"+function);
			}
		return listFunctions;
	}*/
	
	public List<DependentModules> findByFunctionalityId(Long funcId) {
		System.out.println("In service class" + repo);
	
		List<DependentModules> listFunctions=repo.findByFunctionalityId(funcId);
		for(DependentModules function:listFunctions){
			System.out.println("function in service class::::::::::::"+function);
			}
		return listFunctions;
	}
	
}
