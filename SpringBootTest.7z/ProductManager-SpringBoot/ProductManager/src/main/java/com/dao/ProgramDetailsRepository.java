package com.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.DependentModules;
import com.model.ProgramDetails;


@Repository
public interface ProgramDetailsRepository extends JpaRepository<ProgramDetails, Long>	 {
   
	public List<ProgramDetails> findByDependentModulesId(Long funcId);
}
