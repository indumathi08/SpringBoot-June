package com.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.DependentModules;


@Repository
public interface DepModuleRepository extends JpaRepository<DependentModules, Long>	 {
   
	public List<DependentModules> findByFunctionalityId(Long funcId);
}
