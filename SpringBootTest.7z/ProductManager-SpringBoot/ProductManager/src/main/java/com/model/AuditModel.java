package com.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)

public abstract class AuditModel implements Serializable {

    private static final long serialVersionUID = 1L;

    
    @Column(name = "created_dt", nullable = false, updatable = false)
    @CreatedDate
    private Date created_dt;

 
    @Column(name = "updated_dt", nullable = false)
    @LastModifiedDate
    private Date updated_dt;
    

    @Column(name = "created_by", nullable = false, updatable = false)
    private String created_by;

    
    @Column(name = "updated_by", nullable = false)
    private String updated_by;


	public Date getCreated_dt() {
		return created_dt;
	}


	public void setCreated_dt(Date created_dt) {
		this.created_dt = created_dt;
	}


	public Date getUpdated_dt() {
		return updated_dt;
	}


	public void setUpdated_dt(Date updated_dt) {
		this.updated_dt = updated_dt;
	}


	public String getCreated_by() {
		return created_by;
	}


	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}


	public String getUpdated_by() {
		return updated_by;
	}


	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

    
    

	
    

  }