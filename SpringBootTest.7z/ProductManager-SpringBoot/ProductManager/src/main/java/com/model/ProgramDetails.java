package com.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ProgramDetails")
public class ProgramDetails extends AuditModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String programName;
	private String environment;	
	private String repoDetails;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "dependentModules_id")
	private DependentModules dependentModules;
	
	public ProgramDetails() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	

	public String getRepoDetails() {
		return repoDetails;
	}

	public void setRepoDetails(String repoDetails) {
		this.repoDetails = repoDetails;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public DependentModules getDependentModules() {
		return dependentModules;
	}

	public void setDependentModules(DependentModules dependentModules) {
		this.dependentModules = dependentModules;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public ProgramDetails(Long id, String programName, String environment, DependentModules dependentModules,
			String repoDetails) {
		super();
		this.id = id;
		this.programName = programName;
		this.environment = environment;
		this.dependentModules = dependentModules;
		this.repoDetails=repoDetails;
	}

	

}
