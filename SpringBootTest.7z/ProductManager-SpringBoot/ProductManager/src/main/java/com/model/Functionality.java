package com.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="FUNCTIONALITY")
public class Functionality extends AuditModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String funcName;
	@OneToMany(mappedBy = "functionality", cascade = {
	        CascadeType.ALL
	    })
	    private List < DependentModules > dependentModules;
	

	public Functionality() {
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getFuncName() {
		return funcName;
	}


	public void setFuncName(String funcName) {
		this.funcName = funcName;
	}


	public List<DependentModules> getDependentModules() {
		return dependentModules;
	}


	public void setDependentModules(List<DependentModules> dependentModules) {
		this.dependentModules = dependentModules;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public Functionality(Long id, String funcName, List<DependentModules> dependentModules) {
		super();
		this.id = id;
		this.funcName = funcName;
		this.dependentModules = dependentModules;
	}

	

	
	
}
