package com.model;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="DependentModules")
public class DependentModules extends AuditModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String depModuleName;
	 @ManyToOne(cascade = CascadeType.ALL)
	 @JoinColumn(name = "functionality_id")
	  private Functionality functionality;
	 
	 @OneToMany(mappedBy = "dependentModules", cascade = {
		        CascadeType.ALL
		    })
		    private List < ProgramDetails > programDetails;
	
	public DependentModules() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDepModuleName() {
		return depModuleName;
	}

	public void setDepModuleName(String depModuleName) {
		this.depModuleName = depModuleName;
	}

	public Functionality getFunctionality() {
		return functionality;
	}

	public void setFunctionality(Functionality functionality) {
		this.functionality = functionality;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<ProgramDetails> getProgramDetails() {
		return programDetails;
	}

	public void setProgramDetails(List<ProgramDetails> programDetails) {
		this.programDetails = programDetails;
	}

	public DependentModules(Long id, String depModuleName, Functionality functionality,
			List<ProgramDetails> programDetails) {
		super();
		this.id = id;
		this.depModuleName = depModuleName;
		this.functionality = functionality;
		this.programDetails = programDetails;
	}

	
	

		
}
